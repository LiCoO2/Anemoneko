﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public List<AudioClip> audioClips;
    public AudioSource audioSource;

    private void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }

    public void PlayAudio(int value)
    {
        if(value == 3)
        {
            audioSource.volume = 0.3f;
        }
        else
        {
            audioSource.volume = 1f;
        }

        audioSource.clip = audioClips[value];
        audioSource.Play(0);
    }
}
