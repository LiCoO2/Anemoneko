﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeScene : MonoBehaviour
{
    public void OpenScene(int value)
    {
        SingletonPattern.Instance.Init();
        UnityEngine.SceneManagement.SceneManager.LoadScene(value);        
    }

}
