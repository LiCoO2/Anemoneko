﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DropDownMenu : MonoBehaviour
{
    public bool active = false;
    public GameObject activeObject;
    public GameObject questObject;
    public Image currentImage;
    public GameManager gameManager;

    public List<Sprite> flowerSprites;
    public List<Image> images;
    public int index = 4;

    public void ActiveMenu()
    {
        if (!active)
        {
            questObject.transform.position += Vector3.down * 190f;
            activeObject.SetActive(true);
            active = true;
        }
    }

    public void PassiveMenu()
    {
        questObject.transform.position += Vector3.up * 190f;
        activeObject.SetActive(false);
        active = false;
    }

    public void ClickLeftSide()
    {
        if(index <= 4)
        {

        }
        else if(index <= 8)
        {
            index = 0;
            ImageRefresh();
        }
        else
        {
            index -= 8;
            ImageRefresh();
        }
    }

    public void ClickRightSide()
    {
        if(index > flowerSprites.Count - 4)
        {
            index = flowerSprites.Count - 4;
            ImageRefresh();
        }
        else if(index == flowerSprites.Count)
        {

        }
        else
        {
            index = flowerSprites.Count - 4;
            ImageRefresh();
        }
    }

    public void ImageRefresh()
    {
        foreach (Image image in images)
        {
            image.sprite = flowerSprites[index];
            index++;
        }
    }
    public void ClickFlowerImage(int value)
    {
        currentImage.sprite = flowerSprites[index - value];
        gameManager.currentFlower = (FlowerName)(index - value);
        gameManager.audioManager.PlayAudio(2);
    }
}
