﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Flower : MonoBehaviour
{
    public int flowerNameOnNumber;
    private int flowerWaterMaxHp;
    private int flowerWaterCurrentHp;
    private int flowerFertilizeMaxHp;
    private int flowerFertilizeCurrentHp;
    private int flowerBuyPrice;
    private int flowerSellPrice;
    private int flowerSellTime;

    public Slider waterSlider;
    public Slider fertilizeSlider;
    public Slider timeSlider;

    public void Init(Flowers_ScriptableObject flowers)
    {
        flowerNameOnNumber = flowers.flowerNameOnNumber;
        flowerWaterMaxHp = flowers.flowerWaterMaxHp;
        flowerWaterCurrentHp = flowers.flowerWaterCurrentHp;
        flowerFertilizeMaxHp = flowers.flowerFertilizeMaxHp;
        flowerFertilizeCurrentHp = flowers.flowerFertilizeCurrentHp;
        flowerBuyPrice = flowers.flowerBuyPrice;
        flowerSellPrice = flowers.flowerSellPrice;
        flowerSellTime = flowers.flowerSellTime;

        waterSlider.maxValue = flowerWaterMaxHp;
        waterSlider.value = flowerWaterCurrentHp;
        fertilizeSlider.maxValue = flowerFertilizeMaxHp;
        fertilizeSlider.value = flowerFertilizeCurrentHp;
        timeSlider.maxValue = flowerSellTime;
        timeSlider.value = flowerSellTime;

        GetComponent<Image>().sprite = flowers.flowerSprite;
    }

    /// <summary>
    /// 체력 감소 매서드
    /// </summary>
    /// <param name="WaterOrFertilize">0 = 물체력감소, 1 = 비료체력감소</param>
    /// <param name="value">감소값</param>
    /// <returns>true = 감소성공, false = 체력 0 이하</returns>
    public void HpDown(int WaterOrFertilize, int value)
    {
        switch (WaterOrFertilize)
        {
            case 0:
                if ((flowerWaterCurrentHp - value) <= 0)
                {
                    SingletonPattern.Instance.FlowerDeadUp((FlowerName)flowerNameOnNumber);
                    Destroy(gameObject);
                }                    
                else
                    flowerWaterCurrentHp -= value;
                break;
            case 1:
                if ((flowerFertilizeCurrentHp - value) <= 0)
                {
                    SingletonPattern.Instance.FlowerDeadUp((FlowerName)flowerNameOnNumber);
                    Destroy(gameObject);
                }                    
                else
                    flowerFertilizeCurrentHp -= value;
                break;
            default:
                Debug.Log(WaterOrFertilize + " is fail in HpDown");
                break;
        }
    }

    /// <summary>
    /// 체력 증가 매서드
    /// </summary>
    /// <param name="WaterOrFertilize">0 = 물체력증가, 1 = 비료체력증가</param>
    /// <param name="value">증가값</param>
    public void HpUp(int WaterOrFertilize, int value)
    {
        switch (WaterOrFertilize)
        {
            case 0:
                if (flowerWaterMaxHp < (flowerWaterCurrentHp + value))
                    flowerWaterCurrentHp = flowerWaterMaxHp;
                else
                    flowerWaterCurrentHp += value;
                break;
            case 1:
                if (flowerFertilizeMaxHp < (flowerFertilizeCurrentHp + value))
                    flowerFertilizeCurrentHp = flowerFertilizeMaxHp;
                else
                    flowerFertilizeCurrentHp += value;
                break;
            default:
                Debug.Log(WaterOrFertilize + " is fail in HpUp");
                break;
        }
        ReDrawSlider();
    }

    public bool TimeReduce(int value)
    {
        flowerSellTime -= value;
        ReDrawSlider();

        if (flowerSellTime < 0)
            return false;

        return true;
    }

    public int GetBuyPrice()
    {
        return flowerBuyPrice;
    }

    public int GetSellPrice()
    {
        return flowerSellPrice;
    }

    public void ReDrawSlider()
    {
        fertilizeSlider.value = flowerFertilizeCurrentHp;
        waterSlider.value = flowerWaterCurrentHp;
        timeSlider.value = flowerSellTime;
    }
}
