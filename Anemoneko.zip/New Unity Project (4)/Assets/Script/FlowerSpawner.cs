﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlowerSpawner : MonoBehaviour
{
    public List<Flowers_ScriptableObject> flowers_ScriptableObjects;
    public GameObject flowerPrefabs;

    public Flower FlowerSpawn(FlowerName flowerName, Transform pos)
    {
        Flower flower = Instantiate(flowerPrefabs, pos).GetComponent<Flower>();
        flower.Init(flowers_ScriptableObjects[(int)flowerName]);
        return flower;
    }
}
