﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Flower", menuName = "ScriptableObject/Flower Data")]
public class Flowers_ScriptableObject : ScriptableObject
{
    public int flowerNameOnNumber;
    public Sprite flowerSprite;
    public int flowerWaterMaxHp;
    public int flowerWaterCurrentHp;
    public int flowerFertilizeMaxHp;
    public int flowerFertilizeCurrentHp;
    public int flowerBuyPrice;
    public int flowerSellPrice;
    public int flowerSellTime;
}
