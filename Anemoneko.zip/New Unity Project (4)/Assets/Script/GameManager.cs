﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum FlowerName { Cosmos, Pansy, Anemone, Iris, Tulip };

public class GameManager : MonoBehaviour
{
    public int gold;
    public int days;
    public int waterOrFertilize;    //0 = Water, 1 = Fertilize
    public int heal;            //회복량, 난이도 변수
    public int damage;          //시간당 입는 데미지, 난이도 변수
    public int warmDamage;      //한 번 클릭시 벌래가 받는 데미지
    public FlowerName currentFlower = FlowerName.Cosmos;

    public Text goldText;
    public Text daysText;
    public GameObject gameOverImage;

    public List<Room> rooms;

    public FlowerSpawner flowerSpawner;
    public WarmSpawner warmSpawner;

    public AudioManager audioManager;

    private void Start()
    {
        Debug.Log("This is GameManager's Start()");

        gold = SingletonPattern.Instance.playerData.gold;
        days = SingletonPattern.Instance.playerData.days;
        heal = SingletonPattern.Instance.playerData.heal;
        damage = SingletonPattern.Instance.playerData.damage;
        warmDamage = SingletonPattern.Instance.playerData.warmDamage;
        currentFlower = SingletonPattern.Instance.playerData.currentFlower;

        if (SingletonPattern.Instance.playerData.rooms == null)
            SingletonPattern.Instance.playerData.rooms = rooms;

        goldText.text = gold.ToString();
        daysText.text = "Days : " + days.ToString();
    }

    //꽃 변경 블럭 선택시 실행될 매서드
    public void SetCurrentFlower(FlowerName flowerName)
    {
        currentFlower = flowerName;
    }

    //물 블럭 선택시 0로, 비료 블럭 선택시 1로 주고 실행되는 매서드
    public void SetWaterOrFertilize(int value)
    {
        waterOrFertilize = value;
        audioManager.PlayAudio(value);
    }

    //꽃 심는 영역 선택시 영역별 위치에 따라 0~8값 주고 실행되는 매서드
    public void ClickEvent(int roomNum)
    {
        if (rooms[roomNum].ClickEvent(waterOrFertilize, heal, warmDamage, flowerSpawner, currentFlower))
            GoldDown(rooms[roomNum].BuyFlower());
        audioManager.PlayAudio(3);
    }

    //타임 이벤트 시간에 맞춰 한 번씩 실행(시간은 TimeManager 참고)
    public void TimeEvent(int value)
    {
        foreach(Room room in rooms)
        {
            if (room.IsRoomEmpty())
                continue;

            if (room.RoomTimeEvent(value, damage))
                GoldUp(room);
        }
    }

    //벌래 스폰 시간에 맞춰 한 번씩 실행(시간은 TimeManager 참고)
    public void WarmSpawnEvent()
    {
        int randomValue = Random.Range(1,5);

        List<Room> warmRooms = new List<Room>();

        foreach(Room room in rooms)
        {
            if (!room.IsRoomEmpty())
                warmRooms.Add(room);
        }
        bool value = true;

        while (value)
        {
            if (warmRooms.Count != 0)
            {
                int randomPos = Random.Range(0, warmRooms.Count - 1);

                if (warmRooms[randomPos].GetIsWarm())
                {
                    warmRooms.RemoveAt(randomPos);      
                }
                else
                {
                    warmRooms[randomPos].WarmSpawn(randomValue, warmSpawner);
                    value = false;
                }
            }
            else
            {
                value = false;
            }
        }
    }

    //하루 끝나는 시간에 맞춰 한 번 실행(시간은 TimeManager 참고)
    public void TimeOver()
    {
        Time.timeScale = 0;
        gameOverImage.SetActive(true);

        SingletonPattern.Instance.playerData.gold = gold;
        SingletonPattern.Instance.playerData.currentFlower = currentFlower;
        SingletonPattern.Instance.playerData.rooms = rooms;
        SingletonPattern.Instance.playerData.days++;
    }

    public void GoldUp(Room room)
    {
        int currentGold;
        currentGold = room.SellFlower();
        gold += currentGold;
        goldText.text = gold.ToString();
        SingletonPattern.Instance.GoldUp(currentGold);
        room.DestroyFlower();
        audioManager.PlayAudio(4);
    }

    public void GoldDown(int value)
    {
        int currentGold;
        currentGold = value;
        gold -= currentGold;
        goldText.text = gold.ToString();
    }
}