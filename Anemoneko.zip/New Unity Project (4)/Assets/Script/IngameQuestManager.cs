﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IngameQuestManager : MonoBehaviour
{
    public Text questContentText;
    public string questContentTextString;

    private void Start()
    {
        questContentTextString = SingletonPattern.Instance.currentQuest.questInGameContent;
    }

    public void UpdateQuest()
    {
        questContentTextString = SingletonPattern.Instance.currentQuest.questInGameContent;
        questContentText.text = questContentTextString + " " + SingletonPattern.Instance.alreadyHasItem + "/ " + SingletonPattern.Instance.currentQuest.needItem;
    }
}
