﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerData : MonoBehaviour
{
    public int gold;
    public int days;
    public int heal;
    public int damage;
    public int warmDamage;
    public FlowerName currentFlower;

    public List<Room> rooms;

    public Dictionary<FlowerName, int> flowerPlanted;
    public Dictionary<FlowerName, int> flowerSelled;
    public Dictionary<FlowerName, int> flowerDestroyed;

    public void Init()
    {
        flowerPlanted = new Dictionary<FlowerName, int>();

        flowerPlanted.Add(FlowerName.Cosmos, 0);
        flowerPlanted.Add(FlowerName.Pansy, 0);
        flowerPlanted.Add(FlowerName.Anemone, 0);
        flowerPlanted.Add(FlowerName.Iris, 0);
        flowerPlanted.Add(FlowerName.Tulip, 0);

        flowerSelled = new Dictionary<FlowerName, int>();

        flowerSelled.Add(FlowerName.Cosmos, 0);
        flowerSelled.Add(FlowerName.Pansy, 0);
        flowerSelled.Add(FlowerName.Anemone, 0);
        flowerSelled.Add(FlowerName.Iris, 0);
        flowerSelled.Add(FlowerName.Tulip, 0);

        flowerDestroyed = new Dictionary<FlowerName, int>();

        flowerDestroyed.Add(FlowerName.Cosmos, 0);
        flowerDestroyed.Add(FlowerName.Pansy, 0);
        flowerDestroyed.Add(FlowerName.Anemone, 0);
        flowerDestroyed.Add(FlowerName.Iris, 0);
        flowerDestroyed.Add(FlowerName.Tulip, 0);
    }
}
