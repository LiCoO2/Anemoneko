﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum QuestType { FullGoldTracking, StageGoldTracking, FlowerSellTracking, CosmosSellTracking, PansySellTracking, AnemoneSellTracking, IrisSellTracking, TulipSellTracking }

[CreateAssetMenu(fileName = "Quest", menuName = "ScriptableObject/Quest Data")]
public class Quest_ScriptableObject : ScriptableObject
{
    public string questName;
    public string questInGameContent;
    public int needItem;
    public QuestType questType;
    public List<TalkScript> talkScripts;
}
