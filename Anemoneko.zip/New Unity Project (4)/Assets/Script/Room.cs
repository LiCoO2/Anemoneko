﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room : MonoBehaviour
{

    private Flower flower;
    private Warm warm;
    private bool isWarmed = false;

    public bool IsRoomEmpty()
    {
        if (flower == null)
            return true;
        return false;
    }

    public bool GetIsWarm()
    {
        return isWarmed;
    }

    public bool RoomTimeEvent(int value, int damage)
    {
        flower.HpDown(0, damage);
        flower.HpDown(1, damage);

        if (!flower.TimeReduce(value))
            return true;

        return false;
    }

    public bool ClickEvent(int WaterOrFertilize, int heal, int warmDamage, FlowerSpawner flowerSpawner, FlowerName flowerName)
    {
        if (isWarmed)
        {
            if (!warm.Reduce(warmDamage))
            {
                isWarmed = false;
                Destroy(warm.gameObject);
                return false;
            }
            return false;
        }            
        else
        {
            if (IsRoomEmpty())
            {
                flower = flowerSpawner.FlowerSpawn(flowerName, gameObject.transform);
                SingletonPattern.Instance.FlowerPlantUp(flowerName);
                return true;
            }
            else
            {
                flower.HpUp(WaterOrFertilize, heal);
                return false;
            }
        }
    }

    public void WarmSpawn(int value, WarmSpawner warmSpawner)
    {
        warm = warmSpawner.WarmSpawn(gameObject.transform);
        warm.Init(value);
        isWarmed = true;
    }

    public int SellFlower()
    {
        return flower.GetSellPrice();
    }

    public int BuyFlower()
    {
        return flower.GetBuyPrice();
    }

    public void DestroyFlower()
    {
        SingletonPattern.Instance.FlowerSellUp((FlowerName)flower.flowerNameOnNumber);
        Destroy(flower.gameObject);
    }
}