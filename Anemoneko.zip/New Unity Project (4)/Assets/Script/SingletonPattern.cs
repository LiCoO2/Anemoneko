﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum ValueUpType { Gold}
public class SingletonPattern : MonoBehaviour
{
    public PlayerData playerData;
    public List<Quest_ScriptableObject> quests;
    public Quest_ScriptableObject currentQuest;

    public int alreadyHasItem;

    public int questIndex;

    private static SingletonPattern instance;

    public static SingletonPattern Instance
    {
        get
        {
            if (instance == null)
            {
                var obj = FindObjectOfType<SingletonPattern>();
                if (obj != null)
                {
                    instance = obj;
                }
                else
                {
                    var newSingleton = new GameObject("Singleton Class").AddComponent<SingletonPattern>();
                    instance = newSingleton;
                }
            }
            return instance;
        }
        private set
        {
            instance = value;
        }
    }
    private void Awake()
    {
        Debug.Log("Singleton's Awake");
        var objs = FindObjectsOfType<SingletonPattern>();
        if (objs.Length != 1)
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);

        playerData.Init();
        currentQuest = quests[questIndex];
        alreadyHasItem = 0;
    }

    private void Start()
    {
        Debug.Log("Singleton's Start()");
        playerData.Init();
    }

    public void Init()
    {
        Debug.Log("Singleton's Init()");

        if (Instance.alreadyHasItem >= Instance.currentQuest.needItem)
            Instance.NextQuest();
    }

    public void NextQuest()
    {
        Debug.Log("I have a NextQuest!");
        alreadyHasItem = 0;
        questIndex++;

        if (questIndex >= quests.Count)
            UnityEngine.SceneManagement.SceneManager.LoadScene(3);
        else
        {
            currentQuest = quests[questIndex];
        }

    }

    public List<TalkScript> GetTalkScripts()
    {
        return currentQuest.talkScripts;
    }

    public void QuestRefresh()
    {
        switch (currentQuest.questType)
        {
            case QuestType.FullGoldTracking:

                break;
            case QuestType.StageGoldTracking:

                break;
            case QuestType.FlowerSellTracking:

                break;
            case QuestType.CosmosSellTracking:

                break;
            case QuestType.PansySellTracking:

                break;
            case QuestType.AnemoneSellTracking:

                break;
            case QuestType.IrisSellTracking:

                break;
            case QuestType.TulipSellTracking:

                break;
        }
    }

    public void FlowerPlantUp(FlowerName flowerName)
    {
        playerData.flowerPlanted[flowerName]++;

        /*
        switch (flowerName)
        {
            case FlowerName.Cosmos:

                break;
            case FlowerName.Pansy:

                break;

            case FlowerName.Anemone:

                break;

            case FlowerName.Iris:

                break;

            case FlowerName.Tulip:

                break;
        }
        */
    }

    public void FlowerSellUp(FlowerName flowerName)
    {
        playerData.flowerSelled[flowerName]++;

        if (currentQuest.questType == QuestType.FlowerSellTracking)
            alreadyHasItem++;

        switch (flowerName)
            {
                case FlowerName.Cosmos:
                    if (currentQuest.questType == QuestType.CosmosSellTracking)
                        alreadyHasItem++;
                    break;
                case FlowerName.Pansy:
                        if (currentQuest.questType == QuestType.PansySellTracking)
                    alreadyHasItem++;
                    break;
                case FlowerName.Anemone:
                        if (currentQuest.questType == QuestType.AnemoneSellTracking)
                    alreadyHasItem++;
                    break;
                case FlowerName.Iris:
                        if (currentQuest.questType == QuestType.IrisSellTracking)
                    alreadyHasItem++;
                    break;
                case FlowerName.Tulip:
                        if (currentQuest.questType == QuestType.TulipSellTracking)
                    alreadyHasItem++;
                    break;
            }

    }

    public void FlowerDeadUp(FlowerName flowerName)
    {
        /*
        switch (flowerName)
        {
            case FlowerName.Cosmos:

                break;
            case FlowerName.Pansy:

                break;

            case FlowerName.Anemone:

                break;

            case FlowerName.Iris:

                break;

            case FlowerName.Tulip:

                break;
        }
        */
    }

    public void GoldUp(int value)
    {
        if(currentQuest.questType == QuestType.StageGoldTracking)
            alreadyHasItem++;
    }
}
