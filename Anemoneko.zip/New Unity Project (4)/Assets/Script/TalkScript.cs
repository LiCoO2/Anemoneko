﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum CutScenePeople { Null, Rui, Grandfather, Docter, VillageCheif }

[CreateAssetMenu(fileName = "Talk", menuName = "ScriptableObject/Talk Data")]
public class TalkScript : ScriptableObject
{
    public CutScenePeople cutScenePeople;
    public string talkContent;
}
