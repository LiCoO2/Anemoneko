﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextManager : MonoBehaviour
{
    public GameObject nextText;
    public GameObject gameStartText;
    public GameObject sceneChangeCol;

    public GameObject leftSideTalkBackground;
    public GameObject rightSideTalkBackground;

    public Image leftSideCharacter;
    public Image rightSideCharacter;

    public List<Sprite> characterSprites;

    public Text leftTalkText;
    public Text rightTalkText;

    public Text leftCharacterName;
    public Text rightCharacterName;

    public List<TalkScript> talkScripts;

    public int talkIndex;
    public CutScenePeople currentTalkWho;

    private void Start()
    {
        talkScripts = SingletonPattern.Instance.GetTalkScripts();
        currentTalkWho = CutScenePeople.Null;
        ViewNextTalk();
    }

    public void ViewNextTalk()
    {
        if (talkIndex > talkScripts.Count - 1)
        {
            nextText.SetActive(false);
            gameStartText.SetActive(true);
            sceneChangeCol.SetActive(true);
        }
        else
        {
            switch (talkScripts[talkIndex].cutScenePeople)
            {
                case CutScenePeople.Rui:
                    leftTalkText.text = talkScripts[talkIndex].talkContent;
                    if (currentTalkWho == CutScenePeople.Rui)
                    {
                        break;
                    }
                    leftCharacterName.text = "루이";
                    leftSideCharacter.sprite = characterSprites[0];
                    leftSideTalkBackground.SetActive(true);
                    rightSideTalkBackground.SetActive(false);
                    break;
                case CutScenePeople.Grandfather:
                    rightTalkText.text = talkScripts[talkIndex].talkContent;
                    if (currentTalkWho == CutScenePeople.Grandfather)
                    {
                        break;
                    }
                    rightCharacterName.text = "할아버지";
                    rightSideCharacter.sprite = characterSprites[1];

                    if (currentTalkWho == CutScenePeople.Rui || currentTalkWho == CutScenePeople.Null)
                    {
                        leftSideTalkBackground.SetActive(false);
                        rightSideTalkBackground.SetActive(true);
                        break;
                    }
                    break;
                case CutScenePeople.Docter:
                    rightTalkText.text = talkScripts[talkIndex].talkContent;
                    if (currentTalkWho == CutScenePeople.Docter)
                    {
                        break;
                    }
                    rightCharacterName.text = "의사";
                    rightSideCharacter.sprite = characterSprites[2];

                    if(currentTalkWho == CutScenePeople.Rui || currentTalkWho == CutScenePeople.Null)
                    {
                        leftSideTalkBackground.SetActive(false);
                        rightSideTalkBackground.SetActive(true);
                        break;
                    }
                    break;
                case CutScenePeople.VillageCheif:
                    rightTalkText.text = talkScripts[talkIndex].talkContent;
                    if (currentTalkWho == CutScenePeople.VillageCheif)
                    {
                        break;
                    }
                    rightCharacterName.text = "마을 이장";
                    rightSideCharacter.sprite = characterSprites[3];

                    if (currentTalkWho == CutScenePeople.Rui || currentTalkWho == CutScenePeople.Null)
                    {
                        leftSideTalkBackground.SetActive(false);
                        rightSideTalkBackground.SetActive(true);
                        break;
                    }
                    break;
                default:
                    Debug.Log("Bug");
                    break;
            }
            currentTalkWho = talkScripts[talkIndex].cutScenePeople;
            talkIndex++;
        }        
    }
}
