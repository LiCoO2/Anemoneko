﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TimeManager : MonoBehaviour
{
    public GameManager gameManager;
    public IngameQuestManager ingameQuestManager;

    public float inGameTime;
    public float startTime;
    public float endTime;
    public float eventTime;
    public float warmSpawnTime;
    private float warmSpawnCurrentTime;

    public Slider timeSlider;

    private void Start()
    {
        inGameTime = 0;
        Time.timeScale = 1;
        Debug.Log(Time.time);
        timeSlider.maxValue = endTime;
        timeSlider.value = endTime;

        ingameQuestManager.UpdateQuest();

        warmSpawnCurrentTime = warmSpawnTime;
    }

    private void Update()
    {
        if(Time.timeSinceLevelLoad > (startTime + inGameTime))
        {
            //StartTime 시간 후 부터 eventTime초 마다 내부 1회 실행
            inGameTime += eventTime;

            //GameManager에 있는 Time이벤트 실행
            if(inGameTime >= endTime)
            {
                gameManager.TimeOver();
            }
            else
            {
                timeSlider.value -= eventTime;
                Debug.Log("Now Time is : " + inGameTime);
                gameManager.TimeEvent((int)eventTime);
                ingameQuestManager.UpdateQuest();
            }

            //벌래 생성 이벤트
            warmSpawnCurrentTime -= eventTime;

            if(warmSpawnCurrentTime <= 0f)
            {
                gameManager.WarmSpawnEvent();
                warmSpawnCurrentTime = warmSpawnTime;
            }
        }
    }
}
