﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Warm : MonoBehaviour
{
    private int warmHp;
    private Image image;

    public List<Sprite> wramSprites;

    public void Init(int value)
    {
        warmHp = value;
        image = GetComponent<Image>();
        image.sprite = wramSprites[warmHp - 1];
    }

    public bool Reduce(int value)
    {
        if((warmHp - value) <= 0)
        {
            return false;
        }
        else
        {
            warmHp -= value;
            image.sprite = wramSprites[warmHp - 1];
            return true;
        }
    }
}