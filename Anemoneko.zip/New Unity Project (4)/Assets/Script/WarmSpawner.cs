﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarmSpawner : MonoBehaviour
{
    public GameObject warmPrefab;

    public Warm WarmSpawn(Transform pos)
    {
        return Instantiate(warmPrefab, pos).GetComponent<Warm>();
    }
}